use strict;

my @files=glob("*.pdb");
for my $file(@files)
{
	open In,"<",$file;
	$file=~/(.*)\.pdb/;
	my $Pr=uc($1);
	while(<In>)
	{
		if(/^ATOM/)
		{
			my @temp=split /\s+/;
            my $flag_side=substr($_,21,1);
			if(!($temp[2]=~/^H/))
			{
				open Out,">>","../".$Pr."_".$flag_side.".pdb";
				printf Out "%s",$_;
				close Out;
			}
		}
	}
}
